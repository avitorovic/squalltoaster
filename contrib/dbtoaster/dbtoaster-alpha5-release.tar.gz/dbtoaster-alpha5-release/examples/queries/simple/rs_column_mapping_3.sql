CREATE STREAM R(A int, B int)
  FROM FILE 'examples/data/simple/r.dat' LINE DELIMITED csv;

CREATE STREAM S(C int, D int)
  FROM FILE 'examples/data/simple/s.dat' LINE DELIMITED csv;

SELECT r1.A, r1.B FROM S s, R r1, R r2 WHERE s.C=r2.A AND s.D = r2.A;
